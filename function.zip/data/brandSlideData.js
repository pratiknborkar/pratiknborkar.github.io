module.exports = [
  {
    id: 1,
    img: "/images/slider/AWS.png",
  },
  {
    id: 2,
    img: "/images/slider/CKA.png",
  },
  {
    id: 3,
    img: "/images/slider/ITIL.png",
  },
  {
    id: 4,
    img: "/images/slider/OCI.png",
  },
];
