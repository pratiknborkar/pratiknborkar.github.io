import Home from "./home";


const MainRoot = () => {
  return <Home />;
};

export default MainRoot;
